package com.imagebuilder;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ImageBuilderMod implements ModInitializer {
	public static final String MOD_ID = "imagebuilder";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Папка, куда кладутся картинки: <папка игры>/imagebuilder */
	public static Path imagesDir() {
		return FabricLoader.getInstance().getGameDir().resolve("imagebuilder").toAbsolutePath().normalize();
	}

	@Override
	public void onInitialize() {
		try {
			Files.createDirectories(imagesDir());
		} catch (IOException e) {
			LOGGER.warn("Не удалось создать папку {}", imagesDir(), e);
		}

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				BuildCommand.register(dispatcher));
		ServerTickEvents.END_SERVER_TICK.register(BuildQueue::tick);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> BuildQueue.clear());
	}
}
