package com.imagebuilder;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Набор блоков с примерными средними цветами текстур. Падающие/растущие/окисляющиеся блоки не используются. */
public final class Palette {
	public static final String[] NAMES = {"all", "concrete", "wool", "terracotta", "gray"};

	private static final String[] DYES = {
			"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
			"light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"
	};

	private static final int[][] CONCRETE = {
			{207, 213, 214}, {224, 97, 0}, {169, 48, 159}, {35, 137, 198},
			{240, 175, 21}, {94, 168, 24}, {213, 101, 142}, {54, 57, 61},
			{125, 125, 115}, {21, 119, 136}, {100, 31, 156}, {44, 46, 143},
			{96, 60, 32}, {73, 91, 36}, {142, 32, 32}, {8, 10, 15}
	};

	private static final int[][] WOOL = {
			{233, 236, 236}, {240, 118, 19}, {189, 68, 179}, {58, 175, 217},
			{248, 198, 39}, {112, 185, 25}, {237, 141, 172}, {62, 68, 71},
			{142, 142, 134}, {21, 137, 145}, {121, 42, 172}, {53, 57, 157},
			{114, 71, 40}, {84, 109, 27}, {161, 39, 34}, {20, 21, 25}
	};

	private static final int[][] TERRACOTTA = {
			{209, 177, 161}, {161, 83, 37}, {149, 88, 108}, {112, 108, 138},
			{186, 133, 36}, {103, 117, 53}, {160, 77, 78}, {57, 41, 35},
			{135, 107, 98}, {87, 92, 92}, {122, 73, 88}, {76, 62, 92},
			{76, 50, 35}, {76, 82, 42}, {142, 60, 46}, {37, 22, 16}
	};

	private record Extra(String id, int r, int g, int b) {}

	private static final List<Extra> EXTRAS = List.of(
			new Extra("snow_block", 249, 254, 254),
			new Extra("stone", 125, 125, 125),
			new Extra("smooth_stone", 158, 158, 158),
			new Extra("deepslate", 80, 80, 82),
			new Extra("polished_blackstone", 53, 49, 57),
			new Extra("blackstone", 42, 36, 41),
			new Extra("netherrack", 98, 38, 38),
			new Extra("nether_bricks", 44, 22, 26),
			new Extra("quartz_block", 236, 230, 223),
			new Extra("gold_block", 246, 208, 61),
			new Extra("iron_block", 220, 220, 220),
			new Extra("diamond_block", 98, 237, 228),
			new Extra("emerald_block", 42, 203, 87),
			new Extra("lapis_block", 31, 67, 140),
			new Extra("redstone_block", 171, 27, 9),
			new Extra("coal_block", 16, 15, 15),
			new Extra("oak_planks", 162, 130, 78),
			new Extra("spruce_planks", 114, 84, 48),
			new Extra("birch_planks", 192, 175, 121),
			new Extra("jungle_planks", 160, 115, 81),
			new Extra("acacia_planks", 168, 90, 50),
			new Extra("dark_oak_planks", 66, 43, 20),
			new Extra("mangrove_planks", 118, 54, 49),
			new Extra("cherry_planks", 226, 178, 172),
			new Extra("crimson_planks", 101, 48, 70),
			new Extra("warped_planks", 43, 104, 99),
			new Extra("bamboo_planks", 193, 173, 81),
			new Extra("sandstone", 216, 203, 155),
			new Extra("red_sandstone", 186, 99, 29),
			new Extra("clay", 160, 166, 179),
			new Extra("moss_block", 89, 109, 45),
			new Extra("glowstone", 171, 131, 84),
			new Extra("prismarine", 99, 171, 158),
			new Extra("dark_prismarine", 51, 91, 75),
			new Extra("purpur_block", 169, 125, 169),
			new Extra("end_stone", 219, 222, 158),
			new Extra("bricks", 150, 97, 83),
			new Extra("mud_bricks", 137, 103, 79),
			new Extra("packed_ice", 141, 180, 250),
			new Extra("amethyst_block", 133, 97, 191),
			new Extra("bone_block", 229, 225, 207)
	);

	private static final Set<String> GRAY_EXTRAS = Set.of(
			"snow_block", "stone", "smooth_stone", "deepslate", "iron_block", "coal_block", "polished_blackstone");

	private static final Map<String, Palette> CACHE = new ConcurrentHashMap<>();

	private record Entry(BlockState state, int r, int g, int b) {}

	public final BlockState[] states;
	public final int[] pr;
	public final int[] pg;
	public final int[] pb;
	/** Если true, картинку перед подбором переводим в оттенки серого. */
	public final boolean gray;

	private Palette(List<Entry> list, boolean gray) {
		int n = list.size();
		this.states = new BlockState[n];
		this.pr = new int[n];
		this.pg = new int[n];
		this.pb = new int[n];
		for (int i = 0; i < n; i++) {
			Entry e = list.get(i);
			states[i] = e.state();
			pr[i] = e.r();
			pg[i] = e.g();
			pb[i] = e.b();
		}
		this.gray = gray;
	}

	public static boolean exists(String name) {
		for (String n : NAMES) {
			if (n.equals(name)) return true;
		}
		return false;
	}

	/** Вызывать только из серверного потока (нужен реестр блоков). */
	public static Palette get(String name) {
		Palette p = CACHE.get(name);
		if (p == null) {
			p = build(name);
			CACHE.put(name, p);
		}
		return p;
	}

	private static Palette build(String name) {
		List<Entry> l = new ArrayList<>();
		boolean gray = false;
		switch (name) {
			case "concrete" -> addAll(l, "_concrete", CONCRETE);
			case "wool" -> addAll(l, "_wool", WOOL);
			case "terracotta" -> {
				addAll(l, "_terracotta", TERRACOTTA);
				add(l, "terracotta", 152, 94, 67);
			}
			case "gray" -> {
				gray = true;
				for (int i : new int[]{0, 7, 8, 15}) {
					add(l, DYES[i] + "_concrete", CONCRETE[i][0], CONCRETE[i][1], CONCRETE[i][2]);
					add(l, DYES[i] + "_wool", WOOL[i][0], WOOL[i][1], WOOL[i][2]);
				}
				for (Extra e : EXTRAS) {
					if (GRAY_EXTRAS.contains(e.id())) add(l, e.id(), e.r(), e.g(), e.b());
				}
			}
			default -> {
				addAll(l, "_concrete", CONCRETE);
				addAll(l, "_wool", WOOL);
				addAll(l, "_terracotta", TERRACOTTA);
				add(l, "terracotta", 152, 94, 67);
				for (Extra e : EXTRAS) add(l, e.id(), e.r(), e.g(), e.b());
			}
		}
		ImageBuilderMod.LOGGER.info("Палитра '{}': {} блоков", name, l.size());
		return new Palette(l, gray);
	}

	private static void addAll(List<Entry> l, String suffix, int[][] table) {
		for (int i = 0; i < DYES.length; i++) {
			add(l, DYES[i] + suffix, table[i][0], table[i][1], table[i][2]);
		}
	}

	private static void add(List<Entry> l, String id, int r, int g, int b) {
		Block block = Registries.BLOCK.get(Identifier.of("minecraft", id));
		if (block == Blocks.AIR) {
			ImageBuilderMod.LOGGER.warn("Неизвестный блок в палитре: {}", id);
			return;
		}
		l.add(new Entry(block.getDefaultState(), r, g, b));
	}

	/** Индекс ближайшего по цвету блока (метрика "redmean"). */
	public int nearest(int r, int g, int b) {
		int best = 0;
		long bestD = Long.MAX_VALUE;
		for (int i = 0; i < pr.length; i++) {
			int mr = (r + pr[i]) / 2;
			int dr = r - pr[i];
			int dg = g - pg[i];
			int db = b - pb[i];
			long d = (long) (512 + mr) * dr * dr + 1024L * dg * dg + (long) (767 - mr) * db * db;
			if (d < bestD) {
				bestD = d;
				best = i;
			}
		}
		return best;
	}
}
