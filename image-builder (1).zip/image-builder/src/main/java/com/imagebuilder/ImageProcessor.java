package com.imagebuilder;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

/** Чтение картинки, уменьшение (усреднение по областям, без Graphics2D) и подбор блоков. */
public final class ImageProcessor {
	public static final int MAX_SIZE = 256;

	/** indices[i] — индекс блока в палитре или -1 для прозрачного пикселя. */
	public record Result(int width, int height, int[] indices) {}

	private ImageProcessor() {}

	public static BufferedImage read(InputStream in) throws IOException {
		BufferedImage img = ImageIO.read(in);
		if (img == null) {
			throw new IOException("Формат не поддерживается (нужен PNG, JPG, GIF или BMP)");
		}
		return img;
	}

	public static Result convert(BufferedImage img, int requestedWidth, Palette palette, boolean dither) {
		int sw = img.getWidth();
		int sh = img.getHeight();

		int tw = Math.max(1, Math.min(requestedWidth, MAX_SIZE));
		int th = Math.max(1, Math.round((float) sh * tw / sw));
		if (th > MAX_SIZE) {
			th = MAX_SIZE;
			tw = Math.max(1, Math.round((float) sw * th / sh));
		}

		int[] src = img.getRGB(0, 0, sw, sh, null, 0, sw);

		int total = tw * th;
		float[] fr = new float[total];
		float[] fg = new float[total];
		float[] fb = new float[total];
		int[] al = new int[total];

		double xs = (double) sw / tw;
		double ys = (double) sh / th;

		for (int ty = 0; ty < th; ty++) {
			int y0 = Math.min(sh - 1, (int) Math.floor(ty * ys));
			int y1 = Math.min(sh, Math.max(y0 + 1, (int) Math.ceil((ty + 1) * ys)));
			for (int tx = 0; tx < tw; tx++) {
				int x0 = Math.min(sw - 1, (int) Math.floor(tx * xs));
				int x1 = Math.min(sw, Math.max(x0 + 1, (int) Math.ceil((tx + 1) * xs)));

				long sa = 0, sr = 0, sg = 0, sb = 0;
				int n = 0;
				for (int y = y0; y < y1; y++) {
					int row = y * sw;
					for (int x = x0; x < x1; x++) {
						int p = src[row + x];
						int a = p >>> 24;
						sa += a;
						sr += (long) ((p >> 16) & 255) * a;
						sg += (long) ((p >> 8) & 255) * a;
						sb += (long) (p & 255) * a;
						n++;
					}
				}

				int i = ty * tw + tx;
				if (sa == 0) {
					al[i] = 0;
					continue;
				}
				al[i] = (int) (sa / n);
				float r = sr / (float) sa;
				float g = sg / (float) sa;
				float b = sb / (float) sa;
				if (palette.gray) {
					float l = 0.299f * r + 0.587f * g + 0.114f * b;
					r = l;
					g = l;
					b = l;
				}
				fr[i] = r;
				fg[i] = g;
				fb[i] = b;
			}
		}

		int[] out = new int[total];
		for (int y = 0; y < th; y++) {
			for (int x = 0; x < tw; x++) {
				int i = y * tw + x;
				if (al[i] < 128) {
					out[i] = -1;
					continue;
				}
				float r = clamp(fr[i]);
				float g = clamp(fg[i]);
				float b = clamp(fb[i]);
				int idx = palette.nearest(Math.round(r), Math.round(g), Math.round(b));
				out[i] = idx;

				if (dither) {
					float er = r - palette.pr[idx];
					float eg = g - palette.pg[idx];
					float eb = b - palette.pb[idx];
					spread(fr, fg, fb, tw, th, x + 1, y, er, eg, eb, 7f / 16f);
					spread(fr, fg, fb, tw, th, x - 1, y + 1, er, eg, eb, 3f / 16f);
					spread(fr, fg, fb, tw, th, x, y + 1, er, eg, eb, 5f / 16f);
					spread(fr, fg, fb, tw, th, x + 1, y + 1, er, eg, eb, 1f / 16f);
				}
			}
		}
		return new Result(tw, th, out);
	}

	private static void spread(float[] fr, float[] fg, float[] fb, int w, int h,
							   int x, int y, float er, float eg, float eb, float k) {
		if (x < 0 || y < 0 || x >= w || y >= h) return;
		int j = y * w + x;
		fr[j] += er * k;
		fg[j] += eg * k;
		fb[j] += eb * k;
	}

	private static float clamp(float v) {
		return v < 0f ? 0f : Math.min(v, 255f);
	}
}
