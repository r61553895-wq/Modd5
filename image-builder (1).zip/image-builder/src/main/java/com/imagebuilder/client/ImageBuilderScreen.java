package com.imagebuilder.client;

import com.imagebuilder.ImageBuilderMod;
import com.imagebuilder.ImageProcessor;
import com.imagebuilder.Palette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

/** Меню: перетащи картинку в окно (или выбери файл), настрой и нажми «Построить». */
public class ImageBuilderScreen extends Screen {
	private static final Set<String> EXT = Set.of("png", "jpg", "jpeg", "gif", "bmp");
	private static final int PANEL_X = 10;
	private static final int PANEL_W = 150;

	// Настройки помним между открытиями меню
	private static int blocksWidth = 64;
	private static int paletteIdx = 0;
	private static boolean dither = true;
	private static boolean floor = false;

	private BufferedImage image;
	private Path source;
	private volatile ImageProcessor.Result result;
	private volatile Palette resultPalette;
	private int version = 0;
	private String status = "";

	private ButtonWidget paletteBtn;
	private ButtonWidget ditherBtn;
	private ButtonWidget modeBtn;
	private ButtonWidget buildBtn;

	public ImageBuilderScreen() {
		super(Text.literal("Image Builder"));
	}

	@Override
	protected void init() {
		int x = PANEL_X;
		int y = 30;

		addDrawableChild(ButtonWidget.builder(Text.literal("Выбрать файл..."), b -> chooseFile())
				.dimensions(x, y, PANEL_W, 20).build());
		y += 24;

		addDrawableChild(new WidthSlider(x, y, PANEL_W, 20));
		y += 24;

		paletteBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
			paletteIdx = (paletteIdx + 1) % Palette.NAMES.length;
			refreshLabels();
			requestConvert();
		}).dimensions(x, y, PANEL_W, 20).build());
		y += 24;

		ditherBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
			dither = !dither;
			refreshLabels();
			requestConvert();
		}).dimensions(x, y, PANEL_W, 20).build());
		y += 24;

		modeBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
			floor = !floor;
			refreshLabels();
		}).dimensions(x, y, PANEL_W, 20).build());
		y += 34;

		buildBtn = addDrawableChild(ButtonWidget.builder(Text.literal("Построить"), b -> build())
				.dimensions(x, y, PANEL_W, 20).build());
		y += 24;

		addDrawableChild(ButtonWidget.builder(Text.literal("Отменить стройку"), b -> undo())
				.dimensions(x, y, PANEL_W, 20).build());
		y += 24;

		addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
				.dimensions(x, y, PANEL_W, 20).build());

		refreshLabels();
	}

	private void refreshLabels() {
		paletteBtn.setMessage(Text.literal("Палитра: " + Palette.NAMES[paletteIdx]));
		ditherBtn.setMessage(Text.literal("Дизеринг: " + (dither ? "вкл" : "выкл")));
		modeBtn.setMessage(Text.literal("Режим: " + (floor ? "на земле" : "стена")));
	}

	// ---------- файлы ----------

	@Override
	public void filesDragged(List<Path> paths) {
		for (Path p : paths) {
			if (isImage(p)) {
				loadImage(p);
				return;
			}
		}
		status = "Нужен файл PNG, JPG, GIF или BMP";
	}

	private void chooseFile() {
		String picked = null;
		try (MemoryStack stack = MemoryStack.stackPush()) {
			PointerBuffer filters = stack.mallocPointer(5);
			for (String f : new String[]{"*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp"}) {
				filters.put(stack.UTF8(f));
			}
			filters.flip();
			picked = TinyFileDialogs.tinyfd_openFileDialog(
					"Select image", null, filters, "Images (png, jpg, gif, bmp)", false);
		} catch (Throwable t) {
			ImageBuilderMod.LOGGER.warn("Не удалось открыть окно выбора файла", t);
			status = "Окно выбора не открылось. Перетащи файл в это окно.";
		}
		if (picked != null && !picked.isEmpty()) {
			loadImage(Path.of(picked));
		}
	}

	private static boolean isImage(Path p) {
		String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
		int dot = n.lastIndexOf('.');
		return dot >= 0 && EXT.contains(n.substring(dot + 1));
	}

	private void loadImage(Path path) {
		if (!isImage(path)) {
			status = "Нужен файл PNG, JPG, GIF или BMP";
			return;
		}
		status = "Загружаю...";
		CompletableFuture.supplyAsync(() -> {
			try (InputStream in = Files.newInputStream(path)) {
				return ImageProcessor.read(in);
			} catch (IOException e) {
				throw new CompletionException(e);
			}
		}).whenComplete((img, err) -> client.execute(() -> {
			if (err != null) {
				Throwable cause = err.getCause() != null ? err.getCause() : err;
				status = "Ошибка: " + cause.getMessage();
				return;
			}
			image = img;
			source = path;
			result = null;
			status = path.getFileName().toString();
			requestConvert();
		}));
	}

	// ---------- конвертация и предпросмотр ----------

	private void requestConvert() {
		if (image == null) return;
		final BufferedImage img = image;
		final int w = blocksWidth;
		final boolean d = dither;
		final Palette pal = Palette.get(Palette.NAMES[paletteIdx]);
		final int ver = ++version;
		CompletableFuture.supplyAsync(() -> ImageProcessor.convert(img, w, pal, d))
				.whenComplete((res, err) -> client.execute(() -> {
					if (ver != version) return;
					if (err != null) {
						status = "Ошибка: " + err.getMessage();
						return;
					}
					result = res;
					resultPalette = pal;
				}));
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		buildBtn.active = result != null;
		super.render(ctx, mouseX, mouseY, delta);

		ctx.drawTextWithShadow(textRenderer, Text.literal("Image Builder"), PANEL_X, 12, 0xFFFFFFFF);
		drawPreview(ctx);

		ImageProcessor.Result r = result;
		String info = status;
		if (r != null) {
			info = status + "  |  " + r.width() + "x" + r.height() + " блоков";
		}
		ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(info), this.width / 2, this.height - 28, 0xFFFFFFFF);
		ctx.drawCenteredTextWithShadow(textRenderer,
				Text.literal("Перетащи картинку в окно. Для стройки нужны читы."),
				this.width / 2, this.height - 16, 0xFFAAAAAA);
	}

	private void drawPreview(DrawContext ctx) {
		int ax = PANEL_X + PANEL_W + 12;
		int ay = 30;
		int aw = this.width - ax - 10;
		int ah = this.height - ay - 36;
		if (aw < 20 || ah < 20) return;

		ctx.fill(ax, ay, ax + aw, ay + ah, 0x80000000);

		ImageProcessor.Result r = result;
		Palette p = resultPalette;
		if (r == null || p == null) {
			String hint = image == null ? "Перетащи сюда картинку" : "Обрабатываю...";
			ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(hint), ax + aw / 2, ay + ah / 2, 0xFFFFFFFF);
			return;
		}

		int stride = Math.max(1, (int) Math.ceil(Math.max(r.width(), r.height()) / 128.0));
		int cx = (r.width() + stride - 1) / stride;
		int cy = (r.height() + stride - 1) / stride;
		int cell = Math.max(1, Math.min((aw - 4) / cx, (ah - 4) / cy));
		int px = ax + (aw - cx * cell) / 2;
		int py = ay + (ah - cy * cell) / 2;

		int[] idxs = r.indices();
		for (int j = 0; j < cy; j++) {
			for (int i = 0; i < cx; i++) {
				int idx = idxs[(j * stride) * r.width() + i * stride];
				if (idx < 0) continue;
				int color = 0xFF000000 | (p.pr[idx] << 16) | (p.pg[idx] << 8) | p.pb[idx];
				ctx.fill(px + i * cell, py + j * cell, px + (i + 1) * cell, py + (j + 1) * cell, color);
			}
		}
	}

	// ---------- действия ----------

	private void build() {
		if (result == null || source == null || client == null || client.player == null) return;
		try {
			String name = stageFile();
			client.player.networkHandler.sendChatCommand("imgbuild run " + blocksWidth + " "
					+ Palette.NAMES[paletteIdx] + " " + dither + " " + (floor ? "floor" : "wall") + " " + name);
			close();
		} catch (IOException e) {
			ImageBuilderMod.LOGGER.warn("Не удалось скопировать файл", e);
			status = "Ошибка копирования: " + e.getMessage();
		}
	}

	private void undo() {
		if (client == null || client.player == null) return;
		client.player.networkHandler.sendChatCommand("imgbuild undo");
		close();
	}

	/** Копирует картинку в папку imagebuilder (с безопасным именем), чтобы серверная часть смогла её прочитать. */
	private String stageFile() throws IOException {
		Path dir = ImageBuilderMod.imagesDir();
		Files.createDirectories(dir);
		String clean = source.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_");
		Path dst = dir.resolve(clean);
		Path src = source.toAbsolutePath().normalize();
		if (!src.equals(dst)) {
			Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
		}
		return clean;
	}

	// ---------- ползунок ширины ----------

	private static int toWidth(double v) {
		return 8 + (int) Math.round(v * 248);
	}

	private final class WidthSlider extends SliderWidget {
		WidthSlider(int x, int y, int w, int h) {
			super(x, y, w, h, Text.empty(), (blocksWidth - 8) / 248.0);
			updateMessage();
		}

		@Override
		protected void updateMessage() {
			setMessage(Text.literal("Ширина: " + toWidth(this.value) + " блоков"));
		}

		@Override
		protected void applyValue() {
			int nw = toWidth(this.value);
			if (nw != blocksWidth) {
				blocksWidth = nw;
				requestConvert();
			}
		}
	}
}
