package com.imagebuilder;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Ставит блоки порциями по несколько тысяч за тик, чтобы сервер не зависал. Помнит последнюю стройку игрока для undo. */
public final class BuildQueue {
	private static final int BLOCKS_PER_TICK = 3000;
	private static final int FLAGS = Block.NOTIFY_LISTENERS;

	private record UndoEntry(BlockPos pos, BlockState oldState) {}

	private record UndoData(ServerWorld world, List<UndoEntry> entries) {}

	private abstract static class Task {
		final UUID owner;

		Task(UUID owner) {
			this.owner = owner;
		}

		/** @return true, когда задача завершена */
		abstract boolean step(int budget);

		abstract void finish(MinecraftServer server);
	}

	private static final Deque<Task> TASKS = new ArrayDeque<>();
	private static final Map<UUID, UndoData> UNDO = new HashMap<>();

	private BuildQueue() {}

	private static final class BuildTask extends Task {
		final ServerWorld world;
		final int w;
		final int h;
		final int[] indices;
		final BlockState[] states;
		final BlockPos origin;
		final Direction forward;
		final Direction right;
		final boolean floor;
		final List<UndoEntry> undo;
		int cursor = 0;
		int placed = 0;
		boolean cancelled = false;

		BuildTask(UUID owner, ServerWorld world, ImageProcessor.Result img, BlockState[] states,
				  BlockPos origin, Direction forward, boolean floor, List<UndoEntry> undo) {
			super(owner);
			this.world = world;
			this.w = img.width();
			this.h = img.height();
			this.indices = img.indices();
			this.states = states;
			this.origin = origin;
			this.forward = forward;
			this.right = forward.rotateYClockwise();
			this.floor = floor;
			this.undo = undo;
		}

		private BlockPos position(int x, int y) {
			int dx = x - w / 2;
			if (floor) {
				// Низ картинки ближе к игроку, верх — дальше
				return origin.down().offset(forward, 2 + (h - 1 - y)).offset(right, dx);
			}
			// Стена перед игроком, низ картинки на уровне ног
			return origin.offset(forward, 3).offset(right, dx).up(h - 1 - y);
		}

		@Override
		boolean step(int budget) {
			if (cancelled) return true;
			int total = indices.length;
			int done = 0;
			while (cursor < total && done < budget) {
				int i = cursor++;
				int idx = indices[i];
				if (idx < 0) continue;
				BlockPos pos = position(i % w, i / w);
				if (world.isOutOfHeightLimit(pos.getY())) continue;
				done++;
				BlockState old = world.getBlockState(pos);
				BlockState state = states[idx];
				if (old == state) continue;
				undo.add(new UndoEntry(pos, old));
				if (world.setBlockState(pos, state, FLAGS)) placed++;
			}
			return cursor >= total;
		}

		@Override
		void finish(MinecraftServer server) {
			if (cancelled) return;
			ServerPlayerEntity p = server.getPlayerManager().getPlayer(owner);
			if (p != null) {
				p.sendMessage(Text.literal("Готово: " + w + "x" + h + ", поставлено блоков: " + placed
						+ ". Отменить: /imgbuild undo"), false);
			}
		}
	}

	private static final class UndoTask extends Task {
		final ServerWorld world;
		final List<UndoEntry> entries;
		int cursor = 0;

		UndoTask(UUID owner, ServerWorld world, List<UndoEntry> entries) {
			super(owner);
			this.world = world;
			this.entries = entries;
		}

		@Override
		boolean step(int budget) {
			int n = 0;
			while (cursor < entries.size() && n < budget) {
				UndoEntry e = entries.get(cursor++);
				world.setBlockState(e.pos(), e.oldState(), FLAGS);
				n++;
			}
			return cursor >= entries.size();
		}

		@Override
		void finish(MinecraftServer server) {
			ServerPlayerEntity p = server.getPlayerManager().getPlayer(owner);
			if (p != null) {
				p.sendMessage(Text.literal("Отмена выполнена, блоков восстановлено: " + entries.size()), false);
			}
		}
	}

	public static boolean hasActive(UUID owner) {
		for (Task t : TASKS) {
			if (t.owner.equals(owner)) return true;
		}
		return false;
	}

	public static void startBuild(ServerPlayerEntity player, ServerWorld world, ImageProcessor.Result img,
								  BlockState[] states, BlockPos origin, Direction facing, boolean floor) {
		List<UndoEntry> undo = new ArrayList<>();
		UNDO.put(player.getUuid(), new UndoData(world, undo));
		TASKS.addLast(new BuildTask(player.getUuid(), world, img, states, origin, facing, floor, undo));
	}

	/** @return сколько блоков будет восстановлено (0 — нечего отменять) */
	public static int undo(ServerPlayerEntity player) {
		UUID uuid = player.getUuid();
		for (Task t : TASKS) {
			if (t.owner.equals(uuid) && t instanceof BuildTask b) {
				b.cancelled = true;
			}
		}
		UndoData data = UNDO.remove(uuid);
		if (data == null || data.entries().isEmpty()) return 0;
		List<UndoEntry> copy = new ArrayList<>(data.entries());
		TASKS.addLast(new UndoTask(uuid, data.world(), copy));
		return copy.size();
	}

	public static void tick(MinecraftServer server) {
		Task t = TASKS.peekFirst();
		if (t == null) return;
		if (t.step(BLOCKS_PER_TICK)) {
			TASKS.pollFirst();
			t.finish(server);
		}
	}

	public static void clear() {
		TASKS.clear();
		UNDO.clear();
	}
}
