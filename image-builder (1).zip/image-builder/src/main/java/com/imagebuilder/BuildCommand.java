package com.imagebuilder;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.stream.Stream;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class BuildCommand {
	private static final long MAX_DOWNLOAD = 32L * 1024 * 1024;
	private static final String[] EXTENSIONS = {"png", "jpg", "jpeg", "gif", "bmp"};
	private static final Set<String> EXT_SET = Set.of(EXTENSIONS);

	private static final Map<UUID, Settings> SETTINGS = new HashMap<>();

	private static final class Settings {
		String palette = "all";
		boolean dither = true;
		boolean floor = false;
	}

	private interface ImageSource {
		BufferedImage load() throws Exception;
	}

	private static final SuggestionProvider<ServerCommandSource> FILE_SUGGESTIONS = (ctx, builder) -> {
		List<String> names = new ArrayList<>();
		for (String n : listImageNames()) {
			names.add(n.contains(" ") ? "\"" + n + "\"" : n);
		}
		return CommandSource.suggestMatching(names, builder);
	};

	private static final SuggestionProvider<ServerCommandSource> PALETTE_SUGGESTIONS =
			(ctx, builder) -> CommandSource.suggestMatching(Arrays.asList(Palette.NAMES), builder);

	private BuildCommand() {}

	public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
		dispatcher.register(literal("imgbuild")
				.requires(src -> src.hasPermissionLevel(2))

				.then(literal("file")
						.then(argument("name", StringArgumentType.string())
								.suggests(FILE_SUGGESTIONS)
								.then(argument("width", IntegerArgumentType.integer(1, ImageProcessor.MAX_SIZE))
										.executes(c -> buildFile(c,
												StringArgumentType.getString(c, "name"),
												IntegerArgumentType.getInteger(c, "width"))))))

				.then(literal("url")
						.then(argument("width", IntegerArgumentType.integer(1, ImageProcessor.MAX_SIZE))
								.then(argument("url", StringArgumentType.greedyString())
										.executes(c -> buildUrl(c,
												IntegerArgumentType.getInteger(c, "width"),
												StringArgumentType.getString(c, "url"))))))

				.then(literal("run")
						.then(argument("width", IntegerArgumentType.integer(1, ImageProcessor.MAX_SIZE))
								.then(argument("palette", StringArgumentType.word())
										.suggests(PALETTE_SUGGESTIONS)
										.then(argument("dither", BoolArgumentType.bool())
												.then(argument("mode", StringArgumentType.word())
														.suggests((ctx, b) -> CommandSource.suggestMatching(List.of("wall", "floor"), b))
														.then(argument("name", StringArgumentType.greedyString())
																.executes(c -> buildRun(c,
																		IntegerArgumentType.getInteger(c, "width"),
																		StringArgumentType.getString(c, "palette"),
																		BoolArgumentType.getBool(c, "dither"),
																		StringArgumentType.getString(c, "mode"),
																		StringArgumentType.getString(c, "name")))))))))

				.then(literal("list").executes(BuildCommand::list))

				.then(literal("undo").executes(BuildCommand::undo))

				.then(literal("palette")
						.then(argument("name", StringArgumentType.word())
								.suggests(PALETTE_SUGGESTIONS)
								.executes(c -> setPalette(c, StringArgumentType.getString(c, "name")))))

				.then(literal("dither")
						.then(argument("on", BoolArgumentType.bool())
								.executes(c -> setDither(c, BoolArgumentType.getBool(c, "on")))))

				.then(literal("mode")
						.then(literal("wall").executes(c -> setMode(c, false)))
						.then(literal("floor").executes(c -> setMode(c, true))))

				.then(literal("settings").executes(BuildCommand::showSettings)));
	}

	// ---------- сборка ----------

	private static int buildFile(CommandContext<ServerCommandSource> c, String name, int width)
			throws CommandSyntaxException {
		Path dir = ImageBuilderMod.imagesDir();
		Path file = resolveImage(dir, name);
		if (file == null) {
			c.getSource().sendError(Text.literal("Файл не найден. Положи картинку в папку: " + dir));
			return 0;
		}
		return start(c, width, settings(c), () -> {
			try (InputStream in = Files.newInputStream(file)) {
				return ImageProcessor.read(in);
			}
		});
	}

	private static int buildUrl(CommandContext<ServerCommandSource> c, int width, String url)
			throws CommandSyntaxException {
		final URI uri;
		try {
			uri = URI.create(url.trim());
		} catch (IllegalArgumentException e) {
			c.getSource().sendError(Text.literal("Некорректная ссылка"));
			return 0;
		}
		String scheme = uri.getScheme();
		if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) {
			c.getSource().sendError(Text.literal("Нужна ссылка http:// или https://"));
			return 0;
		}
		return start(c, width, settings(c), () -> download(uri));
	}

	private static int start(CommandContext<ServerCommandSource> c, int width, Settings s, ImageSource imageSource)
			throws CommandSyntaxException {
		ServerCommandSource source = c.getSource();
		ServerPlayerEntity player = source.getPlayerOrThrow();
		UUID uuid = player.getUuid();

		if (BuildQueue.hasActive(uuid)) {
			source.sendError(Text.literal("Предыдущая стройка ещё идёт. Дождись конца или /imgbuild undo"));
			return 0;
		}

		Palette palette = Palette.get(s.palette);
		boolean dither = s.dither;
		boolean floor = s.floor;
		Direction facing = player.getHorizontalFacing();
		BlockPos origin = player.getBlockPos();
		ServerWorld world = source.getWorld();
		MinecraftServer server = source.getServer();

		source.sendFeedback(() -> Text.literal("Обрабатываю изображение..."), false);

		CompletableFuture.supplyAsync(() -> {
			try {
				return ImageProcessor.convert(imageSource.load(), width, palette, dither);
			} catch (Exception e) {
				throw new CompletionException(e);
			}
		}).whenComplete((result, err) -> server.execute(() -> {
			ServerPlayerEntity p = server.getPlayerManager().getPlayer(uuid);
			if (err != null) {
				Throwable cause = err.getCause() != null ? err.getCause() : err;
				ImageBuilderMod.LOGGER.warn("Ошибка обработки изображения", cause);
				if (p != null) {
					p.sendMessage(Text.literal("Ошибка: " + cause.getMessage()), false);
				}
				return;
			}
			if (p == null) return;
			if (BuildQueue.hasActive(uuid)) {
				p.sendMessage(Text.literal("Стройка уже идёт, эта команда пропущена"), false);
				return;
			}
			BuildQueue.startBuild(p, world, result, palette.states, origin, facing, floor);
			p.sendMessage(Text.literal("Строю " + result.width() + "x" + result.height()
					+ (floor ? " (на земле)" : " (стена)") + "..."), false);
		}));
		return 1;
	}

	/** Команда для GUI: все настройки передаются в самой команде. */
	private static int buildRun(CommandContext<ServerCommandSource> c, int width, String palette,
								boolean dither, String mode, String name) throws CommandSyntaxException {
		if (!Palette.exists(palette)) {
			c.getSource().sendError(Text.literal("Палитры: " + String.join(", ", Palette.NAMES)));
			return 0;
		}
		if (!mode.equals("wall") && !mode.equals("floor")) {
			c.getSource().sendError(Text.literal("Режим: wall или floor"));
			return 0;
		}
		Path dir = ImageBuilderMod.imagesDir();
		Path file = resolveImage(dir, name.trim());
		if (file == null) {
			c.getSource().sendError(Text.literal("Файл не найден в папке: " + dir));
			return 0;
		}
		Settings s = new Settings();
		s.palette = palette;
		s.dither = dither;
		s.floor = mode.equals("floor");
		return start(c, width, s, () -> {
			try (InputStream in = Files.newInputStream(file)) {
				return ImageProcessor.read(in);
			}
		});
	}

	// ---------- загрузка ----------

	private static BufferedImage download(URI uri) throws Exception {
		URLConnection raw = uri.toURL().openConnection();
		if (raw instanceof HttpURLConnection http) {
			http.setInstanceFollowRedirects(true);
		}
		raw.setConnectTimeout(10_000);
		raw.setReadTimeout(30_000);
		raw.setRequestProperty("User-Agent", "ImageBuilderMod/1.0");
		if (raw instanceof HttpURLConnection http && http.getResponseCode() != 200) {
			throw new IOException("HTTP " + http.getResponseCode());
		}
		try (InputStream in = raw.getInputStream()) {
			byte[] data = in.readNBytes((int) MAX_DOWNLOAD + 1);
			if (data.length > MAX_DOWNLOAD) {
				throw new IOException("Файл больше 32 МБ");
			}
			return ImageProcessor.read(new ByteArrayInputStream(data));
		}
	}

	private static Path resolveImage(Path dir, String name) {
		List<String> candidates = new ArrayList<>();
		candidates.add(name);
		for (String ext : EXTENSIONS) {
			candidates.add(name + "." + ext);
		}
		for (String cand : candidates) {
			Path p = dir.resolve(cand).normalize();
			if (p.startsWith(dir) && Files.isRegularFile(p) && isImage(p.getFileName().toString())) {
				return p;
			}
		}
		return null;
	}

	private static boolean isImage(String fileName) {
		int dot = fileName.lastIndexOf('.');
		return dot >= 0 && EXT_SET.contains(fileName.substring(dot + 1).toLowerCase(Locale.ROOT));
	}

	private static List<String> listImageNames() {
		List<String> names = new ArrayList<>();
		Path dir = ImageBuilderMod.imagesDir();
		if (!Files.isDirectory(dir)) return names;
		try (Stream<Path> s = Files.list(dir)) {
			s.filter(Files::isRegularFile)
					.map(p -> p.getFileName().toString())
					.filter(BuildCommand::isImage)
					.sorted()
					.forEach(names::add);
		} catch (IOException e) {
			ImageBuilderMod.LOGGER.warn("Не удалось прочитать папку {}", dir, e);
		}
		return names;
	}

	// ---------- остальные команды ----------

	private static int list(CommandContext<ServerCommandSource> c) {
		List<String> names = listImageNames();
		Path dir = ImageBuilderMod.imagesDir();
		if (names.isEmpty()) {
			c.getSource().sendFeedback(() -> Text.literal("В папке пусто. Положи туда PNG/JPG/GIF/BMP: " + dir), false);
		} else {
			c.getSource().sendFeedback(() -> Text.literal("Папка: " + dir + "\nКартинки: " + String.join(", ", names)), false);
		}
		return names.size();
	}

	private static int undo(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
		ServerPlayerEntity player = c.getSource().getPlayerOrThrow();
		int n = BuildQueue.undo(player);
		if (n == 0) {
			c.getSource().sendError(Text.literal("Нечего отменять"));
			return 0;
		}
		c.getSource().sendFeedback(() -> Text.literal("Отменяю, блоков: " + n + "..."), false);
		return n;
	}

	private static int setPalette(CommandContext<ServerCommandSource> c, String name) throws CommandSyntaxException {
		if (!Palette.exists(name)) {
			c.getSource().sendError(Text.literal("Палитры: " + String.join(", ", Palette.NAMES)));
			return 0;
		}
		settings(c).palette = name;
		c.getSource().sendFeedback(() -> Text.literal("Палитра: " + name), false);
		return 1;
	}

	private static int setDither(CommandContext<ServerCommandSource> c, boolean on) throws CommandSyntaxException {
		settings(c).dither = on;
		c.getSource().sendFeedback(() -> Text.literal("Дизеринг: " + (on ? "вкл" : "выкл")), false);
		return 1;
	}

	private static int setMode(CommandContext<ServerCommandSource> c, boolean floor) throws CommandSyntaxException {
		settings(c).floor = floor;
		c.getSource().sendFeedback(() -> Text.literal("Режим: " + (floor ? "на земле" : "стена")), false);
		return 1;
	}

	private static int showSettings(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
		Settings s = settings(c);
		c.getSource().sendFeedback(() -> Text.literal("Палитра: " + s.palette
				+ ", дизеринг: " + (s.dither ? "вкл" : "выкл")
				+ ", режим: " + (s.floor ? "на земле" : "стена")), false);
		return 1;
	}

	private static Settings settings(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
		return SETTINGS.computeIfAbsent(c.getSource().getPlayerOrThrow().getUuid(), k -> new Settings());
	}
}
